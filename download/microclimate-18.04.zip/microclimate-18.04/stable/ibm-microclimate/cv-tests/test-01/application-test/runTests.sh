#!/bin/bash

oneTimeSetUp() {
  kubectl expose deployment ${release}-ibm-microclimate-devops --type=NodePort --name ${release}-test-devops-svc
  #switch to devops tiller
  helm init --force-upgrade --tiller-namespace default
  sleep 5
  ci=$(kubectl cluster-info)
  echo -e "cluster-info: ${ci}\n"

  ip="icpbuild.rtp.raleigh.ibm.com"
  nodePort=$(kubectl get svc ${release}-test-devops-svc -o jsonpath="{.spec.ports[0].nodePort}")
  echo "oneTimeSetUp: ip=${ip} nodePort=${nodePort}"
}

oneTimeTearDown() {
  echo -e "---- tearDown at the end of runTests.sh ----"
  helm delete microprofile --tiller-namespace default --purge
  kubectl delete project ${projectName}
  kubectl delete svc ${release}-test-devops-svc
}

# Create a test pipeline and check that the deployed application is up and running
testDevopsPipeline() {
  curl -v -H 'Content-Type: application/json' -d "{\"name\":\"${projectName}\",\"gitURL\":\"https://github.com/microclimate-demo/microprofile.git\",\"build\": true, \"deployBranch\": \"master\"}" \
      http://${ip}:${nodePort}/projects?namespace=default

  # There will be a delay while the build runs. We need to wait for the 'demo' chart to be installed
  # and the 'demo-service' to be available. Try waiting up to 10 mins.
  # I'm not using wait_for here because there's a extra diagnostics and logs I want just to be sure life is good.
  retries=0
  while [ "$retries" -le 40 ]; do
    deployments=$(kubectl get deployments --namespace microclimate-pipeline-deployments)
    echo -e "retries=${retries}, deployments = \n'${deployments}\n'"

    # Lack of ${release} in deployment name makes this test very brittle - two simultaneous runs can interfere with each other.
    if [[ $deployments = *microprofile* ]]; then
      echo "Deployment is available"
      break
    fi
    echo "App deployment not ready"

    echo -e "\nProjects: \n"
    kubectl get projects

    echo -e "\nOur project: \n"
    kubectl get project ${projectName} -o yaml

    echo -e "\nNamespaces: \n"
    kubectl get ns

    echo -e "\nJenkins logs last 30s: \n"
    kubectl logs -l app=test-jenkins --since=30s

    echo -e "\nPods in default:\n"
    kubectl get pods

    echo -e "\nPods in deployment ns: \n"
    kubectl get pods -n microclimate-pipeline-deployments

    retries=$((retries+1))
    sleep 20
  done

  wait_for "helm status microprofile --tiller-namespace default" "STATUS: DEPLOYED" 20 10

  # demo pod can still be in 0/1 state at this point: Liberty may still be starting.
  # I'd like to wait for at least one pod to enter ready state but I've not found a good way to do that.
  # Instead we'll wait for HTTP 200 from test app.
  # wait_for doesn't quite work since we're testing for an integer return code.
  testAppNodePort=$(kubectl get svc microprofile-service --namespace microclimate-pipeline-deployments -o jsonpath="{.spec.ports[0].nodePort}")
  if [ -z "$testAppNodePort" ]; then
    echo "Could not locate NodePort for microprofile-service"
    fail "Could not locate NodePort for microprofile-service"
  fi

  i=20
  typeset -i rc
  while [ $i -ge 0 ]; do
    rc=$(curl -s -o /dev/null -w "%{http_code}" http://${ip}:${testAppNodePort})
    if [[ $rc = 200 ]]; then
      echo "Test app is up and ready for use, rc=${rc}"
      break
    fi
    echo "Test app not ready, rc = ${rc}"
    sleep 6
    ((i=i-1))
  done

  duration=$SECONDS
  echo -e "\n+++ Test application ready for use, $((duration / 60 )) minutes and $(( duration % 60 )) seconds\n"
  SECONDS=0

  result=$(curl http://${ip}:${testAppNodePort}/microprofile/v1/example)
  echo $result

  grep 'Congratulations' <<< "${result}" > /dev/null
  echo "grep result: ${?}"
  assertTrue "Bad result from test application: '${msg}'" "[ $? = 0 ]"

}

# wait_for() : Run a command until it returns a particular result.
#   $1: command to exec
#   $2: result to look for
#   $3: try this many times
#   $4: sleep this long between attempts
wait_for() {
  echo -e "Waiting for '${2}' in '${1}'"
  typeset -i i=${3}
  while [ $i -ge 0 ]; do
    echo -e "Exec '${1}'\n"
    result=$($1)
    echo -e "Got '\n${result}\n'"
    if [[ $result = *$2* ]]; then
      echo -e "Found '${2}' in '\n${result}\n'"
      return
    fi
    echo -e "Failed to find '${2}' in '\n${result}\n'"
    ((i=i-1))
    sleep $4
  done
  fail "failure: wait_for waited too long"
}

echo "----- Into runTests.sh -----"

echo "Check for shunit2"
if test -d shunit2; then
  echo "shunit2 found"
else
  git clone https://github.com/kward/shunit2.git shunit2
  echo "shunit2 cloned into shunit2"
fi

echo -e "Invoked with arguments: '\n"
echo $@
echo -e "\n'"

# Grab and store release name
while getopts ":c:" opt; do
  case "${opt}" in
    c)
      release=${OPTARG}
      echo "release = ${release}"
      ;;
  esac
done

projectName=${release}-demo

# unset the args passed from content-tools/travis-tools/build/bin/Makefile.travis in the ICP build scripts - these break shunit2
set --
. shunit2/shunit2
