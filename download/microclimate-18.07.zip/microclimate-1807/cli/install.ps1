#*******************************************************************************
# Licensed Materials - Property of IBM
# "Restricted Materials of IBM"
#
# Copyright IBM Corp. 2017 All Rights Reserved
#
# US Government Users Restricted Rights - Use, duplication or disclosure
# restricted by GSA ADP Schedule Contract with IBM Corp.
#*******************************************************************************

"*****************************************************"
"**          Running Microclimate installer         **"
"*****************************************************"
""
$cli_path = Split-Path -parent $PSCommandPath
$top_path = Split-Path -parent $cli_path

# Check whether the Microclimate CLI is already on the user's PATH
if ($env:path.Contains("microclimate\cli")) {
    "Updating existing PATH entry for Microclimate CLI (mcdev command)"
    $env:path = $env:path -replace "[^;]*microclimate\\cli", $cli_path

} else {
    "Adding Microclimate CLI (mcdev command) to your PATH"
    if (!($env:path.EndsWith(";"))) {
        $env:path += ";" # add separator to user's PATH
    }
    $env:path += $cli_path
    $env:path += ";"
}

# Create microclimate-workspace directory
if ( -not (Test-Path $top_path/microclimate-workspace)) {
  mkdir $top_path/microclimate-workspace > $null
}

# Create .config directory
if ( -not (Test-Path $top_path/microclimate-workspace/.config)) {
  mkdir $top_path/microclimate-workspace/.config > $null
}

# Delete Git file if exists
if (Test-Path $top_path/microclimate-workspace/.config/git.config) {
  rm $top_path/microclimate-workspace/.config/git.config > $null
}

# Initialise Git name and email if they exist
$git_username = "Microclimate User"
$git_email = "microclimate.user@localhost"
$git_config = "$top_path/microclimate-workspace/.config/git.config"
if (git config --get user.name) {
  $git_username = $(git config --get user.name)
}
if (git config --get user.email) {
  $git_email = $(git config --get user.email)
}
echo ""
echo "Initialising Git name and email";
echo "user.name: $git_username"
echo "user.email: $git_email"
git config -f $git_config --add user.name $git_username
git config -f $git_config --add user.email $git_email

# Remove the jdk-cache.log file if it already exists
$parentDir = Split-Path -parent $PSScriptRoot
$cacheFile = "$parentDir\cli\jdk-cache.log"
if (Test-Path $cacheFile) {
    Remove-Item $cacheFile
}

# Pre-build the Liberty JDK Docker image if it doesn't already exist
""
"Checking for cached Liberty JDK Docker image"
$imageOutput = docker images mc-liberty-jdk-cache -q
$FileExists = Test-Path $parentDir\dockerfiles\libertyDockerfile
if (! $imageOutput -And $FileExists) {
    "Starting background job to build Liberty JDK Docker image"
    Start-Job -Name "Liberty-App-Caching" -ScriptBlock {
        $parentDir = $args[0]
        $cacheFile = "$parentDir\cli\jdk-cache.log"
        docker build -t mc-liberty-jdk-cache -f $parentDir\dockerfiles\libertyDockerfile $parentDir\dockerfiles | Out-File $cacheFile
        if ($LastExitCode -ne 0) {
            "Failed to build liberty app image, exit code: $LastExitCode" | Out-File $cacheFile
        }
    } -ArgumentList $parentDir | Out-File $cacheFile
}

""
"Microclimate CLI installed. Run 'mcdev help' for usage instructions"
""
