
#*******************************************************************************
# Licensed Materials - Property of IBM
# "Restricted Materials of IBM"
#
# Copyright IBM Corp. 2017 All Rights Reserved
#
# US Government Users Restricted Rights - Use, duplication or disclosure
# restricted by GSA ADP Schedule Contract with IBM Corp.
#*******************************************************************************
Add-Type -assembly "system.io.compression.filesystem"

"*****************************************************"
"**          Running Microclimate installer         **"
"*****************************************************"
""
$cli_path = Split-Path -parent $PSCommandPath

# Check whether the Microclimate CLI is already on the user's PATH
if ($env:path.Contains("microclimate\cli")) {
    "Updating existing PATH entry for Microclimate CLI (mcdev command)"
    $env:path = $env:path -replace "[^;]*microclimate\\cli", $cli_path

} else {
    "Adding Microclimate CLI (mcdev command) to your PATH"
    if (!($env:path.EndsWith(";"))) {
        $env:path += ";" # add separator to user's PATH
    }
    $env:path += $cli_path
    $env:path += ";"
}

$imageOutput = docker images mc-liberty-jdk-cache -q
$parentDir = Split-Path -parent $PSScriptRoot
$FileExists = Test-Path $parentDir\dockerfiles\libertyDockerfile
if (! $imageOutput -And $FileExists) {
    "Pre-building Liberty app image"
    docker build -t mc-liberty-jdk-cache -f $parentDir\dockerfiles\libertyDockerfile $parentDir\dockerfiles
    if ($LastExitCode -ne 0) {
        "Failed to build liberty app image, exit code: $LastExitCode See previous messages"
    }
}

""
"Run 'mcdev help' for usage instructions"
""