Param( [string]$command )

#*******************************************************************************
# Licensed Materials - Property of IBM
# "Restricted Materials of IBM"
#
# Copyright IBM Corp. 2017, 2019 All Rights Reserved
#
# US Government Users Restricted Rights - Use, duplication or disclosure
# restricted by GSA ADP Schedule Contract with IBM Corp.
#*******************************************************************************

function launch() { # note: 'start' is a reserved word in PowerShell
    "*****************************************************"
    "**                Starting Microclimate            **"
    "*****************************************************"
    $LastExitCode = 0

    "Checking that your local disk is shared in Docker for Windows"
    $local_directory = "/$pwd".Replace("\","/").Replace(":","") # convert to Unix format
    # Run a simple docker container to check that the workspace is mapped ok into docker
    $docker_ls = docker run --rm -v ${local_directory}:/mount_directory alpine ls /mount_directory
    if ($docker_ls | Select-String -Pattern microclimate-workspace) {
      # Found the workspace in the volume mount in docker, all is well
    } else {
      ""
      "Shared drive not available for Microclimate workspace, see https://docs.docker.com/docker-for-windows/#shared-drives for help"
      return
    }

    # Get and start up the microclimate docker images
    docker-compose up -d
    if ($LastExitCode -ne 0) {
        "Microclimate: Error running docker-compose, exit code: $LastExitCode See previous messages"
        return
    }

    # Open up the microclimate portal in the user's browser
    $portal_port = $(docker inspect --format='{{range $p, $conf :=.NetworkSettings.Ports}}{{(index $conf 0).HostPort}}{{end}}' microclimate-portal)
    $count = 0
    while ($count++ -lt 30) { # max 30 secs then timeout
        $html_status = 0
        try {
            $html_status = (Invoke-WebRequest -method head -URI http://localhost:$portal_port).statuscode
        } catch {}
        if ($html_status -eq 200) {
            break # microclimate is up, good to go
        }
        Start-Sleep -s 1
    }
    start "http://localhost:$portal_port"
}

function open() {
    "*****************************************************"
    "**                Opening Microclimate             **"
    "*****************************************************"
    $portal_port = $(docker inspect --format='{{range $p, $conf :=.NetworkSettings.Ports}}{{(index $conf 0).HostPort}}{{end}}' microclimate-portal)
    start "http://localhost:$portal_port"
}

function refresh() {
    "*****************************************************"
    "**      Refreshing Microclimate Docker images      **"
    "*****************************************************"
    docker-compose pull --parallel
}

function stop() {
    "*****************************************************"
    "**                Stopping Microclimate            **"
    "*****************************************************"
    $app_containers = docker ps -a -q  --filter name=mc
    if ($app_containers) {
        "Stopping project application containers"
        docker rm -f $app_containers
    }

    docker-compose down
}

function delete() {
    # First stop any running microclimate containers
    stop
    "*****************************************************"
    "**       Deleting Microclimate Docker images       **"
    "*****************************************************"
    $docker_images = docker images -q "microclimate*"
    if ($docker_images) {
        docker rmi $docker_images
    }
    $docker_images = docker images -q "sys-mcs-docker-local.artifactory.swg-devops.com/microclimate*"
    if ($docker_images) {
        docker rmi $docker_images
    }
    $docker_images = docker images -q "ibmcom/microclimate*"
    if ($docker_images) {
        docker rmi $docker_images
    }
    $docker_images = docker images -q "mc-*"
    if ($docker_images) {
        docker rmi $docker_images
    }
    $docker_images = docker images -q "sys-mcs-docker-local.artifactory.swg-devops.com/mc-*"
    if ($docker_images) {
        docker rmi $docker_images
    }
    $docker_images = docker images -q "ibmcom/mc-*"
    if ($docker_images) {
        docker rmi $docker_images
    }
}

function showHelp() {
    "*****************************************************"
    "**                Microclimate CLI                 **"
    "*****************************************************"
    "Usage:	mcdev COMMAND [options]"
    ""
    "Commands:"
    "  start             Pull Microclimate Docker images and start Microclimate"
    "  stop              Stop Microclimate Docker containers"
    "  open              Open Microclimate in your browser"
    "  refresh           Pull the latest images for the installed version of Microclimate"
    "                    (does not upgrade the Microclimate version)"
    "  healthcheck       Check that Microclimate is set up correctly"
    "  delete            Delete Microclimate Docker images (stops Microclimate first)"
    ""
}

function healthcheck() {
    "*****************************************************"
    "**        Running Microclimate health check        **"
    "*****************************************************"
    ""
    "Checking Microclimate configuration directory"
    if (!(Test-Path -Path microclimate-workspace\.config)) {
        "  Error: Missing Microclimate configuration, re-install needed, see https://microclimate-dev2ops.github.io/installlocally#installing-on-windows"
    }
    ""
    "Checking Microclimate Git configuration"
    if (Test-Path -Path microclimate-workspace\.config\git.config) {
        "  Found Microclimate Git configuration, please verify this information is correct:"
        Get-Content -Path microclimate-workspace\.config\git.config
    } else {
        "  Error: Missing Git configuration, re-install needed, see https://microclimate-dev2ops.github.io/installlocally#installing-on-windows"
    }
    ""
    "Checking that your local disk is shared in Docker Desktop for Windows"
    $local_directory = "/$pwd".Replace("\","/").Replace(":","") # convert to Unix format
    # Run a simple docker container to check that the workspace is mapped ok into docker
    $docker_ls = docker run --rm -v ${local_directory}:/mount_directory alpine ls /mount_directory
    if (!($docker_ls | Select-String -Pattern microclimate-workspace)) {
        "  Error: Shared drive not available for Microclimate workspace, see https://docs.docker.com/docker-for-windows/#shared-drives for help"
    }
    ""
    "Checking Microclimate projects"
    if (Test-Path -Path microclimate-workspace\.projects) {
        $project_count = (Get-Childitem �Path microclimate-workspace\.projects\* -Include *.inf).Count
        "  Found $project_count project(s) in your Microclimate workspace"
    } else {
        "  No projects found in your Microclimate workspace"
    }
    ""
    "Microclimate health check complete"
}

# Start of main program. First check that docker is available (pre-req for Microclimate)
if ((Get-Command "docker.exe" -ErrorAction SilentlyContinue) -eq $null) {
    "Microclimate requires Docker Desktop for Windows, see https://microclimate-dev2ops.github.io/installlocally#installing-on-windows"
    ""
    Exit 1
}

$current_location = Get-Location
$script_location = Split-Path -parent $PSCommandPath

# Run all commands in the main microclimate project directory
Set-Location $script_location\..
# The docker commands expect environment variable $PWD to be set
$env:PWD = $script_location
# Workspace path needs to be in Unix format, e.g /C/Users/user/microclimate/microclimate-workspace
$workspace = "/$pwd/microclimate-workspace".Replace("\","/").Replace(":","")
$Env:WORKSPACE_DIRECTORY = $workspace
$Env:COMPOSE_CONVERT_WINDOWS_PATHS=1
$Env:HOST_OS = "windows"
$Env:PLATFORM="-amd64"

# Create the telemetry ID. Use try/catch block to prevent errors from displaying
# if there are issues getting the mac address via the getmac call
try {
    $macAddress = getmac | Select -Index 3
    $macSplit = $macAddress.split(' ')
    $macAddress = $macSplit[0].trim();
    $macAddress = $macAddress.replace('-',':')
    $telemetryID = $macAddress+$env:UserName
    $data = [system.Text.Encoding]::UTF8.GetBytes($telemetryID)
    $sha1 = New-Object System.Security.Cryptography.SHA1CryptoServiceProvider
    $ResultHash = $sha1.ComputeHash($data)
    $result = ""
    foreach ($byte in $ResultHash) {$result+="{0:x2}" -f $byte}
    $Env:TELEMETRY = "Desktopid-" + $result
}
catch {}

switch ($command) {
    "start" {launch}
    "open" {open}
    "refresh" {refresh}
    "stop" {stop}
    "delete" {delete}
    "help" {showHelp}
    "healthcheck" {healthcheck}
    default {showHelp}
}

# Restore user to their current working directory
Set-Location $current_location
