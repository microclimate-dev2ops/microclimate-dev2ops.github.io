## IBM Cloud Private deployment

#### Prerequisites
* [Docker](https://www.docker.com/get-docker)
* [Kubectl (Kubernetes Command Line Tool)](https://kubernetes.io/docs/tasks/tools/install-kubectl/)

#### Installing Microclimate

Microclimate uses Helm, the package manager for Kubernetes, to provide installation in Kubernetes environments including IBM Cloud Private. For more information about Helm see [https://docs.helm.sh/using_helm/](https://docs.helm.sh/using_helm/).

1. Configure the Kubernetes client API to point to your ICP instance: in the ICP admin GUI, click the account symbol in the top right and go to Configure Client, copy the provided commands and paste them into your local terminal.
2. Allow your ICP instance access to Artifactory:
```bash
kubectl create secret docker-registry artifactory --docker-server=sys-mcs-docker-local.artifactory.swg-devops.com --docker-username=<your-intranet-id> --docker-password=<your-intranet-pwd> --docker-email=<your-email>

kubectl patch serviceaccount default -p '{"imagePullSecrets": [{"name": "artifactory"}]}'
````
3. Run the `helm install` command to deploy Microclimate into your ICP instance. This will create Deployment and Service definitions in ICP and pull the Microclimate docker images from https://hub.docker.com/
```bash
helm install --name microclimate chart/microclimate
```
4. Open the microclimate helm release via the ICP admin GUI, then open the service definition and click on the microclimate portal URL.

To uninstall Microclimate from ICP run the following command:
```bash
helm delete microclimate --purge
```

For information on using persistence storage and other configuration options see [Persistent storage in ICP](https://github.ibm.com/dev-ex/microclimate/wiki/Persistent-storage-in-ICP) and the [Helm chart README](https://github.ibm.com/dev-ex/microclimate/blob/master/chart/microclimate/README.md). For development build instructions and running with a local build of the Microclimate docker images see [Microclimate-Development](https://github.ibm.com/dev-ex/microclimate/wiki/Microclimate-Development).
