## IBM Cloud Private deployment

#### Prerequisites
* [Docker](https://www.docker.com/get-docker)
* [Kubectl (Kubernetes Command Line Tool)](https://kubernetes.io/docs/tasks/tools/install-kubectl/)

#### Installing Microclimate

Microclimate uses Helm, the package manager for Kubernetes, to provide installation in Kubernetes environments including IBM Cloud Private. For more information about Helm see [https://docs.helm.sh/using_helm/](https://docs.helm.sh/using_helm/).

- Configure the Kubernetes client API to point to your ICP instance: in the ICP admin GUI, click the account symbol in the top right and go to Configure Client, copy the provided commands and paste them into your local terminal.

- Run the `helm install` command to deploy Microclimate into your ICP instance. This will create Deployment and Service definitions in ICP and pull the Microclimate docker images from https://hub.docker.com/.
```bash
helm install --name microclimate chart/microclimate
```

To uninstall Microclimate from ICP run the following command:
```bash
helm delete microclimate --purge
```

The [Helm chart README](https://github.ibm.com/dev-ex/microclimate/blob/master/chart/microclimate/README.md) provides further information on using persistence storage and other for more configuration options. For build instructions and running with a local build of the Microclimate docker images see: [Microclimate-Development](https://github.ibm.com/dev-ex/microclimate/wiki/Microclimate-Development)
