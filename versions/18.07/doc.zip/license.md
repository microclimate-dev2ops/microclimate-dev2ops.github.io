---
layout: document
title: Microclimate Licenses
description: Landing page for microclimate licenses
keywords: license
duration: 1 minute
permalink: license
type: document
---

## Microclimate 18.07 Licences

* [IBM License.](./licenses-18_07-ibmlicense)

* [Non IBM Licenses.](./licenses-18_07-nonibmlicense)

## Microclimate 18.06 Licences

* [IBM License.](./licenses-18_06-ibmlicense)

* [Non IBM Licenses.](./licenses-18_06-nonibmlicense)

## Microclimate 18.05 Licences

* [IBM License.](./licenses-18_05-ibmlicense)

* [Non IBM Licenses.](./licenses-18_05-nonibmlicense)

## Microclimate 18.04 Licences

* [IBM License.](./licenses-18_04-ibmlicense)

* [Non IBM Licenses.](./licenses-18_04-nonibmlicense)

## Microclimate 18.03 Licences

* [IBM License.](./licenses-18_03-ibmlicense)

* [Non IBM Licenses.](./licenses-18_03-nonibmlicense)

## Microclimate 18.03beta Licences

* [IBM License.](./licenses-18_03beta-ibmlicense)

* [Non IBM Licenses.](./licenses-18_03beta-nonibmlicense)
