---
layout: document
title: Tutorials and samples
description: Tutorials and samples
keywords: tutorials, samples, examples, testing, simple, fast
duration: 1 minute
auto_ids: true
permalink: tutorials_and_samples
type: document
category: How-tos and Guides
---

## Tutorials

The following tutorial is available for you to use:

* [Adding a New Endpoint to an Application in Microclimate](./addendpoint)

## Samples

The following sample is available for you to download and modify:

* [Rogue Cloud](./roguecloud)
